<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    
    <div class="col-md-4">
      <div class="content mb-3 content-post">
        <article class="post-item">
          <div class="author-meta p-3">
            
            <ul class="w-100 post-meta-group userInfo">
              <li class="mb-4">
                <div class="author">
                  <a href="/author/<?php echo e($author->userName); ?>">
                    <div class="author-img">
                      <img src="/storage/users/<?php echo e($author->img); ?>" class="img-fluid" alt="Responsive image">
                    </div>
                  </a>
                  <h3 class="font-weight-bold mt-4" style="color:#1d68a7;">
                    <?php echo e($author->name); ?>

                    <small>{ <?php echo e($author->userName); ?> }</small>
                  </h3>
                  <span class="tag">
                    <?php echo e($author->posts()->count()); ?> Posts
                  </span>
                  <span class="tag">
                    <?php echo e($author->likes->count()); ?> Likes
                  </span>
                  <span class="tag">
                    <?php echo e($author->comments->count()); ?> Comment
                  </span>
                </div>
              </li>
              
              <li class="info mx-4 font-weight-bold active post">
                See Posts
              </li>
              
              <li class="info mx-4 font-weight-bold inf">
                General Info
              </li>
            </ul>
          </div>
        </article>
      </div>
    </div>
    
    <div class="col-md-6 offset-md-1 posts">
      
      <?php if($author->id == Auth::user()->id): ?>
      <?php echo $__env->make('blog.formPost', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      
      <?php if(session('message')): ?>
      <div class="content">
        <div class="alert alert-info">
          <?php echo e(session('message')); ?>

        </div>
      </div>
      <?php endif; ?>
      <?php if(!$posts->count()): ?>
      <div class="contnet">
        <div class="alert alert-warning">
          <p>No Posts Yet</p>
        </div>
      </div>
      <?php else: ?>
      
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="content mb-3 content-post">
        <article class="post-item">
          <div class="post-meta p-3">
            
            <ul class="post-meta-group">
              <li>
                <div class="author">
                  <a href="/author/<?php echo e($post->author->userName); ?>">
                    <div class="author-img">
                      <img src="/storage/users/<?php echo e($author->img); ?>" alt="authorImg">
                    </div>
                    <h5 class="float-left font-weight-bold " style="color:#1d68a7;">
                      <?php echo e($post->author->name); ?>

                      <span style="font-size:10px;font-weight:100;color:gray;"><?php echo e($post->date); ?></span>
                    </h5>
                  </a>
                </div>
              </li>
              <div class="float-right">
                <li>
                  <small><?php echo e($post->likes->count()); ?></small>
                </li>
                <li class="like">
                  <form action="/blog/<?php echo e($post->id); ?>/likes" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="like">
                      <i class="lni-heart-filled <?php echo e($post->checkUser()); ?>"></i>
                    </button>
                  </form>
                </li>
                <li class="tag">
                  <a href="/category/<?php echo e($post->category->slug); ?>"><?php echo e($post->category->title); ?></a>
                </li>
                <?php if($post->author->id == Auth::user()->id): ?>
                <li class="dropdown">
                  <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false" v-pre><span class="caret more-icon"><i
                        class="lni-more-alt"></i></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
                    
                    <button type="button" class="dropdown-item" data-toggle="modal" data-target="#editForm"
                      style="cursor:pointer">
                      Edit
                    </button>
                    
                    <a class="dropdown-item" href="/blog/<?php echo e($post->id); ?>"
                      onclick="event.preventDefault();
                                                             document.getElementById('delete-form-<?php echo e($post->id); ?>').submit();">
                      <?php echo e(__('Delete')); ?>

                    </a>
                    <form id="delete-form-<?php echo e($post->id); ?>" action="/blog/<?php echo e($post->id); ?>" method="POST"
                      style="display: none;">
                      <?php echo method_field('DELETE'); ?>
                      <?php echo csrf_field(); ?>
                    </form>
                  </div>
                </li>
                <?php endif; ?>
              </div>
            </ul>
            <!-- Edit Modal -->
            <div class="modal fade" id="editForm" tabindex="-1" role="dialog" aria-hidden="true">
              <div class=" modal-dialog content" role="document">
                <div class="modal-content" style="border:none">
                  <h5 class="modal-title p-4 font-weight-bold" style="color:#1d68a7;padding-bottom:.5rem !important;">
                    Edit Post
                  </h5>
                  <div class="modal-body">
                    <form action="/blog/<?php echo e($post->id); ?>" method="post" files=TRUE>
                      <?php echo method_field('patch'); ?>
                      <?php echo csrf_field(); ?>
                      
                      <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                        <div class="col">
                          <textarea class="form-control" name="description" placeholder="Write Post Description Here..."
                            rows="2"><?php echo e($post->description); ?></textarea>
                        </div>
                        <?php if($errors->has('description')): ?>
                        <span class="help-block"><?php echo e($errors->first('description')); ?></span>
                        <?php endif; ?>
                      </div>
                      
                      <div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' : ''); ?>">
                        <div class="col">
                          <select name="category_id" value="<?php echo e($post->category_id); ?>" class="form-control">
                            <option disabled selected>Choose Category
                            </option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>">
                              <?php echo e($category->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <?php if($errors->has('category_id')): ?>
                          <span class="help-block"><?php echo e($errors->first('category_id')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save
                          changes</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="post-item-body">
            <a href="/blog/<?php echo e($post->id); ?>">
              <?php if(!is_null($post->image)): ?>
              <div class="img mt-2">
                <img src="/storage/posts/<?php echo e($post->image); ?>" class="img-thumbnail">
              </div>
              <?php endif; ?>
              <div class="p-3" style="white-space:nowrap;text-overflow:ellipsis;">
                <p class="post-des">
                  <?php echo $post->description; ?>

                </p>
              </div>
            </a>
          </div>
          <hr class="mx-4">
          
          <?php echo $__env->make('blog.comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </article>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <nav>
        <?php echo e($posts->links()); ?>

      </nav>
    </div>
    
    <div class="col-md-6 offset-md-1 information">
      <?php echo $__env->make('blog.authorInf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Main\laravel projects\Blog\resources\views/blog/author.blade.php ENDPATH**/ ?>