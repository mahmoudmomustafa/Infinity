<?php $__env->startSection('content'); ?>
<div class="contain">
    <div class="container py-5">
        <div class="login">
            <div class="row mx-0">
                <div class="col-lg-5 col-md-12 form">
                    <h2 class="p-4 font-weight-bold" style="color:#28cefe">
                        <img src="/img/infinity.svg" width="40"> | Infinity
                    </h2>
                    <h4 class="p-4 font-weight-bold" style="color:#ccdacd">
                        Login To Your Account Now..
                    </h4>
                    <div class="log-form">
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group input">
                                <label for="email" class="font-weight-bold"
                                    style="color:#ccdacd"><?php echo e(__('EMail Address')); ?></label>
                                <input type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    name="email" id="email" value="<?php echo e(old('email')); ?>">
                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="form-group input">
                                <label for="email" class="font-weight-bold"
                                    style="color:#ccdacd"><?php echo e(__('Password')); ?></label>
                                <input id="password" type="password"
                                    class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password"
                                    required autocomplete="current-password">
                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="form-group input " style="display: inline-flex;padding-top:0">
                                <div class="col-md-6">
                                    <div class="form-check pt-2">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                            <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                        <label class="font-weight-bold" style="color:#ccdacd" for="remember">
                                            <?php echo e(__('Remember Me')); ?>

                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="forget">
                                        <?php if(Route::has('password.request')): ?>
                                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Forgot Password?')); ?>

                                        </a>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <div class="form-group row input">
                                <div class="col-md-5 m-auto">
                                    <button type="submit" class="w-100 btn btn-success">
                                        <?php echo e(__('Login')); ?>

                                    </button>
                                </div>
                                <div class="col-md-5 m-auto">
                                    <a class="w-100 btn btn-outline-light" href="<?php echo e(route('register')); ?>">
                                        <?php echo e(__('Register')); ?>

                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-0 col-sm-0 col-md-7 img ">
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Main\laravel projects\infinity\resources\views/auth/login.blade.php ENDPATH**/ ?>