<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="content mb-3 content-post">
        <article class="post-item">
          <div class="user-edit p-4">
            <a href="/author/<?php echo e($author->userName); ?>" class="like">
              | Back
            </a>
          </div>
          <div class="p-4">
            <h2 class="p-4 font-weight-bold" style="color:#28cefe">
              Edit Profile :
            </h2>
            <ul class="w-100 post-meta-group userInfo ml-2">
              
              <li class="d-flex inf-list m-4">
                <h5 class="font-weight-bold pt-1 mr-2" style="width:100px;">Profile Pic</h5>
                <form action="/author/<?php echo e($author->userName); ?>" class="w-100" method="post" enctype="multipart/form-data">
                  <div class="input-group mb-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="file" class="form-control-file w-auto <?php echo e($errors->has('img') ? 'has-error' : ''); ?>"
                  name="img" placeholder="Profile Pic" value="<?php echo e($author->img); ?>">
                    <div class="input-group-append">
                      <button class="btn btn-outline-success">Update</button>
                    </div>
                  </div>
                  <?php if($errors->has('img')): ?>
                  <span class="help-block"><?php echo e($errors->first('img')); ?></span>
                  <?php endif; ?>
                </form>
              </li>
              
              <li class="d-flex inf-list mx-4 mb-4">
                <h5 class="font-weight-bold pt-1 mr-2" style="width:100px;">Full Name</h5>
                <form action="/author/<?php echo e($author->userName); ?>" class="w-100" method="post">
                  <div class="input-group mb-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="text" class="form-control <?php echo e($errors->has('name') ? 'has-error' : ''); ?>" name="name"
                      placeholder="Full Name" value="<?php echo e($author->name); ?>">
                    <div class="input-group-append">
                      <button class="btn btn-outline-success">Update</button>
                    </div>
                  </div>
                  <?php if($errors->has('name')): ?>
                  <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                  <?php endif; ?>
                </form>
              </li>
              
              <li class="d-flex inf-list mx-4 mb-4">
                <h5 class="font-weight-bold pt-1 mr-2" style="width:100px;">User Name </h5>
                <form action="/author/<?php echo e($author->userName); ?>" class="w-100" method="post">
                  <div class="input-group mb-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="text" class="form-control <?php echo e($errors->has('userName') ? 'has-error' : ''); ?>"
                      name="userName" placeholder="User Name" value="<?php echo e($author->userName); ?>">
                    <div class="input-group-append">
                      <button class="btn btn-outline-success">Update</button>
                    </div>
                  </div>
                  <?php if($errors->has('userName')): ?>
                  <span class="help-block"><?php echo e($errors->first('userName')); ?></span>
                  <?php endif; ?>
                </form>
              </li>
              
              <li class="d-flex inf-list mx-4 mb-4">
                <h5 class="font-weight-bold pt-1 mr-2" style="width:100px;">Email </h5>
                <form action="/author/<?php echo e($author->userName); ?>" class="w-100" method="post">
                  <div class="input-group mb-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="email" class="form-control <?php echo e($errors->has('email') ? 'has-error' : ''); ?>" name="email"
                      placeholder="Email Address" value="<?php echo e($author->email); ?>">
                    <div class="input-group-append">
                      <button class="btn btn-outline-success">Update</button>
                    </div>
                  </div>
                  <?php if($errors->has('email')): ?>
                  <span class="help-block"><?php echo e($errors->first('email')); ?></span>
                  <?php endif; ?>
                </form>
              </li>
              
              <li class="d-flex inf-list mx-4 mb-4">
                <h5 class="font-weight-bold pt-1 mr-2" style="width:100px;">Phone Number </h5>
                <form action="/author/<?php echo e($author->userName); ?>" class="w-100" method="post">
                  <div class="input-group mb-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="number" class="form-control <?php echo e($errors->has('number') ? 'has-error' : ''); ?>" name="number"
                      placeholder="Phone Number" value="<?php echo e($author->number); ?>">
                    <div class="input-group-append">
                      <button class="btn btn-outline-success">Update</button>
                    </div>
                  </div>
                  <?php if($errors->has('number')): ?>
                  <span class="help-block"><?php echo e($errors->first('number')); ?></span>
                  <?php endif; ?>
                </form>
              </li>
              
              <li class="d-flex inf-list mx-4 mb-4">
                <h5 class="font-weight-bold pt-1 mr-2" style="width:100px;">Eductaion </h5>
                <form action="/author/<?php echo e($author->userName); ?>" class="w-100" method="post">
                  <div class="input-group mb-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="text" class="form-control <?php echo e($errors->has('education') ? 'has-error' : ''); ?>"
                      name="education" placeholder="Education" value="<?php echo e($author->education); ?>">
                    <div class="input-group-append">
                      <button class="btn btn-outline-success">Update</button>
                    </div>
                  </div>
                  <?php if($errors->has('education')): ?>
                  <span class="help-block"><?php echo e($errors->first('education')); ?></span>
                  <?php endif; ?>
                </form>
              </li>
              
              <li class="d-flex inf-list mx-4 mb-4">
                <h5 class="font-weight-bold pt-1 mr-2" style="width:100px;">BirthDay </h5>
                <form action="/author/<?php echo e($author->userName); ?>" class="w-100" method="post">
                  <div class="input-group mb-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="date" class="form-control <?php echo e($errors->has('birth') ? 'has-error' : ''); ?>" name="birth"
                      placeholder="Birth Date" value="<?php echo e($author->birth); ?>">
                    <div class="input-group-append">
                      <button class="btn btn-outline-success">Update</button>
                    </div>
                  </div>
                  <?php if($errors->has('birth')): ?>
                  <span class="help-block"><?php echo e($errors->first('birth')); ?></span>
                  <?php endif; ?>
                </form>
              </li>
            </ul>
          </div>
        </article>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Main\laravel projects\Blog\resources\views/blog/edit.blade.php ENDPATH**/ ?>