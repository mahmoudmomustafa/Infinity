<div class="comment-body">
  <div class="comments pb-2">
    <article class="post-item pb-4">
      <div class="form-row">
        <div class="col-1 likes ml-4">
          <div class="like d-flex">
            <form id="likable" action="/blog/<?php echo e($post->id); ?>/likes" method="POST">
              <?php echo csrf_field(); ?>
              <button class="like" data-toggle="tooltip" data-placement="left" title="<?php echo e($post->likes->count()); ?> Likes">
                <i class="lni-heart-filled <?php echo e($post->checkUser()); ?>"></i>
              </button>
            </form>
          </div>
        </div>
        <div class="col">
          
          <form action="/blog/<?php echo e($post->id); ?>/comments" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-row justify-content-start mx-0 ml-2">
              <div class="col-md-9 col-9 col-lg-9 col-xl-10" style="position:relative">
                <input class="form-control <?php echo e($errors->has('comment') ? 'is-invalid' : ''); ?>" type="text" name="body"
                  id="comment_<?php echo e($post->id); ?>" placeholder="Write Comment...">
                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                <?php if($errors->has('comment')): ?>
                <div class="invalid-feedback"><?php echo e($errors->first('comment')); ?></div>
                <?php endif; ?>
                <div class="count tag">
                  <small><span><?php echo e($post->comments->count()); ?> Comments</span></small>
                </div>
              </div>
              <div class="col-2 col-md-2  col-lg-2 col-xl-1 p-0">
                <button class="w-100 btn btn-primary" data-toggle="tooltip" data-placement="top" title="Comment"><i
                    class="fas fa-paper-plane"></i></button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </article>
    <?php $__currentLoopData = Request::is('/') ? $post->comments->take(1) : $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="commend mb-2">
      
      <ul class="post-meta-group">
        <li>
          <div class="author">
            <a href="/author/<?php echo e($comment->user->userName); ?>">
              <div class="author-img" style="width:40px;height:40px">
                <img src="/storage/users/<?php echo e($comment->user->img); ?>">
              </div>
              <h6 class="float-left font-weight-bold p-2">
                <?php echo e($comment->user->name); ?>

                <span style="font-size:10px;font-weight:100;color:gray;"> | <?php echo e($comment->date); ?></span>
              </h6>
            </a>
          </div>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $comment)): ?>
        <div class="float-right mr-1">
          <li>
            <a href="/blog/<?php echo e($post->id); ?>/comments/<?php echo e($comment->id); ?>"
              onclick="event.preventDefault();document.getElementById('delete-comment_<?php echo e($comment->id); ?>').submit();">
              <i class="lni-trash trash"></i>
            </a>
            <form id="delete-comment_<?php echo e($comment->id); ?>" action="/blog/<?php echo e($post->id); ?>/comments/<?php echo e($comment->id); ?>"
              method="post" style="display: none;">
              <?php echo method_field('DELETE'); ?>
              <?php echo csrf_field(); ?>
            </form>
          </li>
        </div>
        <?php endif; ?>
      </ul>
      <div class="comment">
        <p class="mb-0">
          <?php echo e($comment->body); ?>

        </p>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div><?php /**PATH D:\Main\laravel projects\infinity\resources\views/blog/comment.blade.php ENDPATH**/ ?>