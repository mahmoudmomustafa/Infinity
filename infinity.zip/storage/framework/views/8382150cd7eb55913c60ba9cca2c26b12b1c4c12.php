<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo e(__('Infinite')); ?></title>
  
  <link href="https://cdn.lineicons.com/1.0.1/LineIcons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Dosis&display=swap" rel="stylesheet">
  <link rel="dns-prefetch" href="//fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Beth+Ellen&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
  <link rel="icon" href="/img/infinity.svg">
  <!-- Styles -->
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="/css/custom.css">
</head>

<body>
  
  <div id="app" style="min-height:100vh">
    <nav id="navbar" class="navbar navbar-expand-md navbar-dark bg-dark shadow">
      <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>" style="color:dimgrey">
          <img src="/img/infinity.svg" width="30"><?php echo e(__(' | Infinity')); ?>

        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
          <i class="lni-angle-double-down"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <!-- Left Side Of Navbar -->
          <ul class="navbar-nav mr-auto">
          </ul>
          <!-- Right Side Of Navbar -->
          <ul class="navbar-nav ml-auto">
            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
            </li>
            <?php if(Route::has('register')): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
            </li>
            <?php endif; ?>
            <?php else: ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('blog')); ?>"><?php echo e(__('Home')); ?></a>
            </li>
            <?php if(Auth::user()->isAdmin()): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <?php echo e(__('Dashboard')); ?>

              </a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
              <a class="nav-link" href="/author/<?php echo e(Auth::user()->userName); ?>"><?php echo e(Auth::user()->firstName()); ?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link pl-0" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                <i class="ml-1 fas fa-sign-out-alt"></i>
              </a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
              </form>
            </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </nav>

    <main class="py-4">
      <?php echo $__env->yieldContent('content'); ?>
    </main>
  </div>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Scripts -->
  <script src="/js/jquery-3.3.1.min.js"></script>
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
  <script src="/js/script.js"></script>
</body>

</html><?php /**PATH D:\Main\laravel projects\infinity\resources\views/layouts/main.blade.php ENDPATH**/ ?>