<div class="comment-body">
  <div class="comments pb-2">
    <article class="post-item">
      
      <form action="/blog/<?php echo e($post->id); ?>/comments" class="pb-4" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-row justify-content-center">
          <div class="col-md-9 col-9 col-lg-9 col-xl-10">
            <input class="form-control <?php echo e($errors->has('comment') ? 'is-invalid' : ''); ?>" type="text" name="body"
              id="comment_<?php echo e($post->id); ?>" placeholder="Write Comment...">
            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
            <?php if($errors->has('comment')): ?>
            <div class="invalid-feedback"><?php echo e($errors->first('comment')); ?></div>
            <?php endif; ?>
          </div>
          <div class="col-2 col-md-2  col-lg-2 col-xl-1">
            <button class="w-100 btn btn-primary" data-toggle="tooltip" data-placement="top" title="Comment"><i
                class="fas fa-paper-plane"></i></button>
          </div>
        </div>
      </form>
    </article>
    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="commend mb-3">
      
      <ul class="post-meta-group">
        <li>
          <div class="author">
            <a href="/author/<?php echo e($comment->user->userName); ?>">
              <div class="author-img">
                <img src="/storage/users/<?php echo e($comment->user->img); ?>" alt="authorImg">
              </div>
              <h6 class="float-left font-weight-bold " style="color:#1d68a7;">
                <?php echo e($comment->user->name); ?>

                <span style="font-size:10px;font-weight:100;color:gray;"><?php echo e($comment->date); ?></span>
              </h6>
            </a>
          </div>
        </li>
        <?php if($comment->user->id == Auth::user()->id): ?>
        <div class="float-right mr-1">
          <li>
            <a href="/blog/<?php echo e($post->id); ?>/comments/<?php echo e($comment->id); ?>"
              onclick="event.preventDefault();document.getElementById('delete-comment_<?php echo e($comment->id); ?>').submit();">
              <i class="lni-trash trash"></i>
            </a>
            <form id="delete-comment_<?php echo e($comment->id); ?>" action="/blog/<?php echo e($post->id); ?>/comments/<?php echo e($comment->id); ?>" method="post"
              style="display: none;">
              <?php echo method_field('DELETE'); ?>
              <?php echo csrf_field(); ?>
            </form>
          </li>
        </div>
        <?php endif; ?>
      </ul>
      <div class="comment">
        <p class="mb-0">
          <?php echo e($comment->body); ?>

        </p>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div><?php /**PATH D:\Main\laravel projects\Blog\resources\views/blog/comment.blade.php ENDPATH**/ ?>