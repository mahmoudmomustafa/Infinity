<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6 offset-md-1">
            
            <?php if(session('message')): ?>
            <div class="content">
                <div class="alert alert-info">
                    <?php echo e(session('message')); ?>

                </div>
            </div>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
            
            <div class="content mb-3">
                <article class="post-item">
                    <h5 class="p-4 font-weight-bold " style="color:#1d68a7;padding-bottom:.5rem !important;">
                        Share Your Thought..
                    </h5>
                    <form action="/" method="post">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <div class="col">
                                <input class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" type="text"
                                    name="title" id="title" placeholder="Post Title...">
                                <?php if($errors->has('title')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('title')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="col">
                                <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>"
                                    name="description" id="description" placeholder="Write Post Description Here..."
                                    rows="2"></textarea>
                                <?php if($errors->has('description')): ?>
                                <span class="invalid-feedback"><?php echo e($errors->first('description')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="col">
                                <select name="category_id" id="category_id"
                                    class="form-control <?php echo e($errors->has('category_id') ? 'is-invalid' : ''); ?>">
                                    <option disabled selected>Choose Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('category_id')): ?>
                                <span class="invalid-feedback"><?php echo e($errors->first('category_id')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-4 offset-md-8 py-2">
                                <button class="w-100 shadow btn btn-primary" type="submit">Post</button>
                            </div>
                        </div>
                    </form>
                </article>
            </div>
            <?php endif; ?>
            <?php if(!$posts->count()): ?>
            <div class="contnet">
                <div class="alert alert-warning">
                    <p>Nothing Found</p>
                </div>
            </div>
            <?php else: ?>
            
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="content mb-3 content-post">
                <article class="post-item">
                    <div class="post-meta p-3" style="padding-bottom: 0 !important;">
                        
                        <ul class="post-meta-group">
                            <li>
                                <div class="author">
                                    <a href="/author/<?php echo e($post->author->userName); ?>">
                                        <div class="author-img">
                                            <img src="/img/user.svg" alt="authorImg">
                                        </div>
                                        <h5 class="float-left font-weight-bold" style="color:#1d68a7;">
                                            <?php echo e($post->author->name); ?>

                                            <span style="font-size:10px;font-weight:100;color:gray;"><?php echo e($post->created_at); ?></span>
                                        </h5>
                                    </a>
                                </div>
                            </li>
                            <span class="float-right">
                                <li class="like">
                                    
                                    <i class="lni-heart-filled"></i>
                                </li>
                                <li class="tag">
                                    <a href="/category/<?php echo e($post->category->slug); ?>"><?php echo e($post->category->title); ?></a>
                                </li>
                                <?php if(Auth::check() && $post->author->id == Auth::user()->id): ?>
                                <li class="dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre><span
                                            class="caret more-icon"><i class="lni-more-alt"></i></span>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
                                        
                                        <button type="button" class="dropdown-item" data-toggle="modal"
                                            data-target="#editForm" style="cursor:pointer">
                                            Edit
                                        </button>
                                        
                                        <a class="dropdown-item" href="/blog/<?php echo e($post->id); ?>" onclick="event.preventDefault();
                                                             document.getElementById('delete-form').submit();">
                                            <?php echo e(__('Delete')); ?>

                                        </a>
                                        <form id="delete-form" action="/blog/<?php echo e($post->id); ?>" method="POST"
                                            style="display: none;">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </li>
                                <?php endif; ?>
                            </span>
                        </ul>
                        <!-- Edit Modal -->
                        <div class="modal fade" id="editForm" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class=" modal-dialog content" role="document">
                                <div class="modal-content" style="border:none">
                                    <h5 class="modal-title p-4 font-weight-bold"
                                        style="color:#1d68a7;padding-bottom:.5rem !important;">Edit Post
                                    </h5>
                                    <div class="modal-body">
                                        <form action="/blog/<?php echo e($post->id); ?>" method="post">
                                            <?php echo method_field('patch'); ?>
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                                <div class="col">
                                                    <input class="form-control" value="<?php echo e($post->title); ?>" type="text"
                                                        name="title" id="title" placeholder="Post Title...">
                                                </div>
                                                <?php if($errors->has('title')): ?>
                                                <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                                                <div class="col">
                                                    <textarea class="form-control" name="description" id="description"
                                                        placeholder="Write Post Description Here..."
                                                        rows="2"><?php echo e($post->description); ?></textarea>
                                                </div>
                                                <?php if($errors->has('description')): ?>
                                                <span class="help-block"><?php echo e($errors->first('description')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' : ''); ?>">
                                                <div class="col">
                                                    <select name="category_id" id="category_id"
                                                        value="<?php echo e($post->category_id); ?>" class="form-control">
                                                        <option disabled selected>Choose Category
                                                        </option>
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($category->id); ?>">
                                                            <?php echo e($category->title); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('category_id')): ?>
                                                    <span class="help-block"><?php echo e($errors->first('category_id')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Save
                                                    changes</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="post-item-body ml-4">
                        <div class="p-4" style="white-space:nowrap;text-overflow:ellipsis;">
                            <h4 class="post-title"><a href="/blog/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h4>
                            <p class="post-des">
                                <?php echo $post->description; ?>

                            </p>
                        </div>
                    </div>
                </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <nav>
                <?php echo e($posts->links()); ?>

            </nav>
        </div>
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Main\laravel projects\Blog\resources\views/blog/index.blade.php ENDPATH**/ ?>