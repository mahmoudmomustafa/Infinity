<?php $__env->startSection('title','MyBlog | Blog index'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Blog
      <small>Display all posts</small>
    </h1>
    <ol class="breadcrumb">
      <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <!-- /.box-header -->
          <div class="box-body ">
            <?php if(session('message')): ?>
            <div class="alert alert-info">
              <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            <?php if(!$posts->count()): ?>
            <div class="alert alert-danger">
              <strong>No record</strong>
            </div>
            <?php else: ?>
            <table class="table taable-bordered">
              <thead>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <a href="/backend/blog/<?php echo e($post->id); ?>/edit" class="btn btn-xs btn-success">
                      <i class="fa fa-edit"></i>
                    </a>
                    <a href="/backend/blog/<?php echo e($post->id); ?>" class="btn btn-xs btn-danger">
                      <i class="fa fa-times"></i>
                    </a>
                  </td>
                  <td><?php echo e($post->title); ?></td>
                  <td><?php echo e($post->author->name); ?></td>
                  <td><?php echo e($post->category->title); ?></td>
                  <td><?php echo e($post->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </thead>
            </table>
            <?php endif; ?>
          </div>
          <!-- /.box-body -->
          
          <nav>
            <?php echo e($posts->links()); ?>

          </nav>
          <!-- /.box -->
        </div>
      </div>
      <!-- ./row -->
  </section>
  <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mahmoud's private folder , don't open it\laravel projects\Blog\resources\views/backend/blog/index.blade.php ENDPATH**/ ?>