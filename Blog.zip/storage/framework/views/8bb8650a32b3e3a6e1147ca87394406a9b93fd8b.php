<?php $__env->startSection('title','MyBlog | Edit category'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
    <!-- Content Header (Page header) -->
    <section class="content-header" style="overflow:auto">
      <h1 class="float-left font-weight-bold " style="color:#1d68a7;">
        <i class="lni-slack"></i> Edit Tag...
      </h1>
      
      <div class="create float-right py-2 mr-2">
        <a href="/dashboard/tags">
          <button class="btn btn-primary btn-add">
            <i class="lni-angle-double-left pr-2"></i>
            Back
          </button>
        </a>
      </div>
    </section>
  
    <!-- Main content -->
    <section class="container  mt-4">
      <div class="row">
        <div class="col">
          <div class="box">
            <!-- /.box-header -->
            <div class="box-body mt-5">
            <form action="/dashboard/tags/<?php echo e($category->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="form-group row">
                  <div class="col-md-6 m-auto">
                    <input type="text" name="title" id="title"
                  class="form-control back-create <?php echo e($errors->has('title') ? 'has-error' : ''); ?>" value="<?php echo e($category->title); ?>" placeholder="Title">
                    <?php if($errors->has('title')): ?>
                    <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-md-6 m-auto">
                    <input type="text" name="slug" id="slug"
                      class="form-control back-create <?php echo e($errors->has('slug') ? 'has-error' : ''); ?>" value="<?php echo e($category->slug); ?>" placeholder="Slug">
                    <?php if($errors->has('slug')): ?>
                    <span class="help-block"><?php echo e($errors->first('slug')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="form-group row mb-0">
                  <div class="col-md-4 m-auto offset-md-6">
                    <button type="submit" class="w-100 btn btn-success">
                      <?php echo e(__('Update')); ?>

                    </button>
                  </div>
                </div>
              </form>
            </div>
            <!-- /.box -->
          </div>
        </div>
        <!-- ./row -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Main\laravel projects\Blog\resources\views/backend/categories/edit.blade.php ENDPATH**/ ?>