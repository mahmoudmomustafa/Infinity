<?php $__env->startSection('title','MyBlog | Edit category'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Blog
      <small>Edit category</small>
    </h1>
    <ol class="breadcrumb">
      <li class="active">
        <a href="/home">Dashboard</a>
      </li>
      
      <li class="active">
        <a href="/backend/categories">Categories</a>
      </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="container  mt-2">
    <div class="row">
      <div class="col">
        <div class="box">
          <!-- /.box-header -->
          <div class="box-body ">
            <form action="/backend/categories/<?php echo e($category->id); ?>" method="post">
              <?php echo method_field('patch'); ?>
              <?php echo csrf_field(); ?>
              <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                <label for="title">title:</label>
                <input type="text" name="title" id="title" class="form-control" value="<?php echo e($category->title); ?>">
                <?php if($errors->has('title')): ?>
                <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                <?php endif; ?>
              </div>
              <div class="form-group <?php echo e($errors->has('slug') ? 'has-error' : ''); ?>">
                <label for="slug">slug:</label>
                <input type="text" name="slug" id="slug" class="form-control" value="<?php echo e($category->slug); ?>">
                <?php if($errors->has('slug')): ?>
                <span class="help-block"><?php echo e($errors->first('slug')); ?></span>
                <?php endif; ?>
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-primary">Update</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
      </div>
      <!-- ./row -->
  </section>
  <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Main\laravel projects\Blog\resources\views/backend/categories/edit.blade.php ENDPATH**/ ?>