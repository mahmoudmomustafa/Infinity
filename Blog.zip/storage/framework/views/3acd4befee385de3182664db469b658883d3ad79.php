<?php $__env->startSection('title','MyBlog | Add Post'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
  <!-- Content Header (Page header) -->
  <section class="content-header" style="overflow:auto">
    <h1 class="float-left font-weight-bold " style="color:#1d68a7;">
      <i class="lni-write"></i> Add Post...
    </h1>
    
    <div class="create float-right py-2 mr-2">
      <a href="/dashboard/posts">
        <button class="btn btn-primary btn-add">
          <i class="lni-angle-double-left pr-2"></i>
          Back
        </button>
      </a>
    </div>
  </section>

  <!-- Main content -->
  <section class="container  mt-4">
    <div class="row">
      <div class="col">
        <div class="box">
          <!-- /.box-header -->
          <div class="box-body ">
            <form action="/dashboard/posts" class="mt-2"method="post">
              <?php echo csrf_field(); ?>
              <div class="form-group row">
                <div class="col-md-6 m-auto">
                  <input type="text" name="title" id="title"
                    class="form-control back-create <?php echo e($errors->has('title') ? 'has-error' : ''); ?>"
                    placeholder="Post Title">
                  <?php if($errors->has('title')): ?>
                  <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                  <?php endif; ?>
                </div>
              </div>
              <div class="form-group row">
                <div class="col-md-6 m-auto">
                  <textarea name="description" id="description" rows="3" placeholder="Post Description"
                    class="form-control back-create <?php echo e($errors->has('description') ? 'has-error' : ''); ?>"></textarea>
                  <?php if($errors->has('description')): ?>
                  <span class="help-block"><?php echo e($errors->first('description')); ?></span>
                  <?php endif; ?>
                </div>
              </div>
              <div class="form-group row">
                <div class="col-md-6 m-auto">
                  <select name="category_id" id="category_id"
                    class="form-control back-create <?php echo e($errors->has('category_id') ? 'has-error' : ''); ?>">
                    <option disabled selected>Choose Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php if($errors->has('category_id')): ?>
                  <span class="help-block"><?php echo e($errors->first('category_id')); ?></span>
                  <?php endif; ?>
                </div>
              </div>
              <div class="form-group row mb-0">
                <div class="col-md-4 m-auto offset-md-6">
                  <button type="submit" class="w-100 btn btn-success">
                    <?php echo e(__('Post')); ?>

                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
  </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Main\laravel projects\Blog\resources\views/backend/blog/create.blade.php ENDPATH**/ ?>