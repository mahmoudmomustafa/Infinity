<?php $__env->startSection('title','MyBlog | Edit User'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      User
      <small>Edit User</small>
    </h1>
    <ol class="breadcrumb">
      <li class="active">
        <a href="/home">Dashboard</a>
      </li>
      
      <li class="active">
        <a href="/backend/users">Users</a>
      </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <!-- /.box-header -->
          <div class="box-body ">
            <form action="/backend/users/<?php echo e($user->id); ?>" method="POST">
              <?php echo method_field('patch'); ?>
              <?php echo csrf_field(); ?>
              <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name">Name:</label>
              <input type="text" name="name" id="name" class="form-control" value="<?php echo e($user->name); ?>">
                <?php if($errors->has('name')): ?>
                <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
              </div>
              <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <label for="email">email:</label>
                <input type="email" name="email" id="email" class="form-control" value="<?php echo e($user->email); ?>">
                <?php if($errors->has('email')): ?>
                <span class="help-block"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
              </div>
              <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                <label for="password">email:</label>
                <input type="password" name="password" id="password" class="form-control" value="<?php echo e($user->password); ?>">
                <?php if($errors->has('password')): ?>
                <span class="help-block"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-primary">Update</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
      </div>
      <!-- ./row -->
  </section>
  <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Main\laravel projects\Blog\resources\views/backend/users/edit.blade.php ENDPATH**/ ?>