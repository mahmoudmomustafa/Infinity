<footer class="home-footer p-2">
    <p style="font-family:'Beth Ellen',cursive;">Copyright © 3M.</p>
    <p class="less-significant">
        <a href="http://localhost:8000/author/Mahmoud">Developed by Mahmoud Mustafa</a>
        <a href="https://www.facebook.com/Mhm0dMhmed"><i class="lni-facebook-filled"></i></a>
        <a href="https://github.com/mahmoudmomustafa/blog"><i class="lni-github-original"></i></a>
    </p>
</footer><?php /**PATH D:\Main\laravel projects\Blog\resources\views/layouts/footer.blade.php ENDPATH**/ ?>