<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-8">
      <article class="post-item post-detail">

        <?php if($post->image_url): ?>
        <div class="post-item-image">
            <img src="<?php echo e($post->image_url); ?>" alt="<?php echo e($post->title); ?>">
        </div>
        <?php endif; ?>

        <div class="post-item-body">
          <div class="padding-10">
            <h1><?php echo e($post->title); ?></h1>

            <div class="post-meta no-border">
              <ul class="post-meta-group">
                <li><i class="fa fa-user"></i><a href="/author/<?php echo e($post->author->slug); ?>"> <?php echo e($post->author->name); ?></a></li>
                <li><i class="fa fa-clock-o"></i><time> <?php echo e($post->date); ?></time></li>
              <li><i class="fa fa-tags"></i><a href="/category/<?php echo e($post->category->slug); ?>"> <?php echo e($post->category->title); ?></a></li>
                <li><i class="fa fa-comments"></i><a href="#">4 Comments</a></li>
              </ul>
            </div>

            <?php echo $post->body_html; ?>


          </div>
        </div>
      </article>

      <article class="post-author padding-10">
        <div class="media">
          <div class="media-left">
            <a href="#">
              <img alt="Author 1" src="/img/author.jpg" class="media-object">
            </a>
          </div>
          <div class="media-body">
            <h4 class="media-heading"><a href="/author/<?php echo e($post->author->slug); ?>"><?php echo e($post->author->name); ?></a></h4>
            <div class="post-author-count">
            <a href="/author/<?php echo e($post->author->slug); ?>">
                <i class="fa fa-clone"></i>
                <?php echo e($post->author->posts->count()); ?> Posts
              </a>
            </div>
            <?php echo $post->author->bio_html; ?>

          </div>
        </div>
      </article>

      
    </div>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mahmoud's private folder , don't open it\laravel projects\Blog\resources\views/blog/show.blade.php ENDPATH**/ ?>