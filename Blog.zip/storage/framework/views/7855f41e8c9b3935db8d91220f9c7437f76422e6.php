<?php $__env->startSection('title','MyBlog | Edit Post'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Blog
      <small>Edit Post</small>
    </h1>
    <ol class="breadcrumb">
      
      <li class="active">
        <a href="<?php echo e(route('dashboard')); ?>>Dashboard</a>
      </li>
      
      <li class=" active">
          <a href="/backend/blog">Posts</a>
      </li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="container  mt-2">
    <div class="row">
      <div class="col">
        <div class="box">
          <!-- /.box-header -->
          <div class="box-body ">
            <form action="/backend/blog/<?php echo e($post->id); ?>" method="POST">
              <?php echo method_field('patch'); ?>
              <?php echo csrf_field(); ?>
              <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                <label for="title">title:</label>
                <input type="text" name="title" id="title" class="form-control" value="<?php echo e($post->title); ?>">
                <?php if($errors->has('title')): ?>
                <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                <?php endif; ?>
              </div>
              <div class="form-group <?php echo e($errors->has('slug') ? 'has-error' : ''); ?>">
                <label for="slug">slug:</label>
                <input type="text" name="slug" id="slug" class="form-control" value="<?php echo e($post->slug); ?>">
                <?php if($errors->has('slug')): ?>
                <span class="help-block"><?php echo e($errors->first('slug')); ?></span>
                <?php endif; ?>
              </div>
              <div class="form-group">
                <label for="excerpt">excerpt:</label>
                <textarea name="excerpt" id="excerpt" cols="5" rows="5"
                  class="form-control"><?php echo e($post->excerpt); ?></textarea>
              </div>
              <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                <label for="description">description:</label>
                <textarea name="description" id="description" cols="10" rows="10"
                  class="form-control"><?php echo e($post->description); ?></textarea>
                <?php if($errors->has('description')): ?>
                <span class="help-block"><?php echo e($errors->first('description')); ?></span>
                <?php endif; ?>
              </div>
              <div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' : ''); ?>">
                <label for="category_id">Category:</label>
                <select name="category_id" id="category_id" class="form-control" value="<?php echo e($post->category_id); ?>">
                  <option disabled selected>Choose Category</option>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('category_id')): ?>
                <span class="help-block"><?php echo e($errors->first('category_id')); ?></span>
                <?php endif; ?>
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-primary">Update</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
      </div>
      <!-- ./row -->
  </section>
  <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Main\laravel projects\Blog\resources\views/backend/blog/edit.blade.php ENDPATH**/ ?>