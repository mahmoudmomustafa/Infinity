<?php $__env->startSection('title','MyBlog | Users'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-4">
  <!-- Content Header (Page header) -->
  <section class="content-header" style="overflow:auto">
    <h1 class="float-left font-weight-bold " style="color:#1d68a7;">
      <i class="lni-users"></i> Display Users...
    </h1>
    
    <div class="create float-right py-2 mr-2">
      <a href="/dashboard/users/create">
        <button class="btn btn-primary btn-add">
           Add<i class="ml-2 lni-plus"></i>
        </button>
      </a>
    </div>
  </section>
  <!-- Main content -->
  <section class="container  mt-4">
    <div class="row">
      <div class="col">
        <div class="box">
          <!-- /.box-header -->
          <div class="box-body ">
            <?php if(session('message')): ?>
            <div class="alert alert-info">
              <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            <?php if(!$users->count()): ?>
            <div class="alert alert-danger">
              <strong>No record</strong>
            </div>
            <?php else: ?>
            <div class="table-responsive">
              <table class="table table-striped table-dark table-hover  table-bordered ">
                <thead>
                  <tr class="font-weight-bold " style="color:#1d68a7;">
                    <td scope="col">Name</td>
                    <td scope="col">Mail</td>
                    <td scope="col" width='90'>Post Count</td>
                    <td scope="col" width='80'>Role</td>
                    <td scope="col" width='80'>Actions</td>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td style="text-align:center;"><?php echo e($user->posts->count()); ?></td>
                    <td><?php echo e($user->role->name); ?></td>
                    <td style="display:flex;">
                      <a href="/dashboard/users/<?php echo e($user->id); ?>/edit" class="mr-2 btn btn-xs btn-success">
                        <i class="fa fa-edit"></i>
                      </a>
                      <form action="/dashboard/users/<?php echo e($user->id); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-xs btn-danger">
                          <i class="fa fa-times"></i>
                        </button>
                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
  </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Main\laravel projects\Blog\resources\views/backend/users/index.blade.php ENDPATH**/ ?>